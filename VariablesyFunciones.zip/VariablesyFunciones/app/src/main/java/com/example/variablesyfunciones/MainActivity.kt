package com.example.variablesyfunciones

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    val nombreUsuario: String = "Ana"
    var edadUsuario: Int = 20
    var promedioNotas: Double = 6.5
    val esMayorDeEdad: Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val saludo = crearSaludo(nombreUsuario, edadUsuario)
        val esAdulto = calcularMayoriaEdad(edadUsuario)
        val mensajeFinal = "$saludo ¿Es mayor de edad? $esAdulto"
        mostrarResultado(mensajeFinal)
    }

    fun crearSaludo(nombre: String, edad: Int): String {
        return "Hola $nombre, tienes $edad años."
    }

    fun calcularMayoriaEdad(edad: Int): Boolean {
        return edad >= 18
    }

    fun mostrarResultado(mensaje: String) {
        val textView: TextView = findViewById(R.id.textView)
        textView.text = mensaje
    }
}

